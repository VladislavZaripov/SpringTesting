create FUNCTION GETFIRSTNAMEBYID
   ( idvalue IN INT )
   RETURN VARCHAR2
IS
  firstNameValue VARCHAR2(100);
 
   cursor c1 is
   SELECT FIRSTNAME
     FROM TESTTABLE
     WHERE ID = idvalue;
 
BEGIN
   open c1;
   fetch c1 into firstNameValue;
 
   if c1%notfound then
      firstNameValue := 'NONAME';
   end if;
   close c1;
RETURN firstNameValue;
END;
/

